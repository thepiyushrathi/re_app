import * as React from "react";
import autoBind from "react-autobind";

import DatePicker from "react-datepicker";
import moment from "moment";
import "react-datepicker/dist/react-datepicker.css";

export default class DateModal extends React.PureComponent {
  constructor(props) {
    super(props);
    autoBind(this);
    //this.state = this.props.currentState;

  }


  render() {
    // console.log('Props', this.props);
    //   console.log('sadads', moment(this.props.currentState));
    return (
        <div>
      <div
        className="modal fade"
        id="myModalDateStart"
        role="dialog"
        aria-labelledby="myModalLabel"
      >
        <div className="modal-dialog" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <button
                type="button"
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
              <h4 className="modal-title" id="myModalLabel">
                Select a Start Date:
              </h4>
            </div>
            <div className="modal-body">
            
              <DatePicker
                inline
                selected={this.props.currentState.startDate
                    ? moment(this.props.currentState.startDate)
                    : null}
                onChange={this.props.handleChangeStart}
              />
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-default"
                data-dismiss="modal"
              >
                Select
              </button>{" "}
              <button
                type="button"
                className="btn btn-default"
                data-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>

      <div
          className="modal fade"
          id="myModalDateEnd"
          role="dialog"
          aria-labelledby="myModalLabel"
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">×</span>
                </button>
                <h4 className="modal-title" id="myModalLabel">
                  Select an End Date:
                </h4>
              </div>
              <div className="modal-body">
                <DatePicker
                inline
                selected={this.props.currentState.endDate
                    ? moment(this.props.currentState.endDate)
                    : null}
                onChange={this.props.handleChangeEnd}
              />
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Select
                </button>{" "}
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
