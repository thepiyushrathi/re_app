import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from "react-redux";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Alert } from 'reactstrap';
import * as topicsActions from "../store/business/actions";
import * as topicsSelectors from "../store/business/reducer";

import BusinessGrid from "../components/BusinessGrid";
import { Link } from "react-router-dom";

const ROOT_ID = 0;

class BusinessScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      columns: [
        { name: "Subject", title: "Task Subject" },
        { name: "Status", title: "Status" },
        {
          name: "Start_Date",
          title: "Start Date",
          getCellValue: row => row.Start_Date.split("T")[0]
        },
        {
          name: "Due_Date",
          title: "Due Date",
          getCellValue: row => row.Due_Date.split("T")[0]
        }
      ],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [],
      defaultHiddenColumnNames: [],
      expandedRowIds: [],
      data: [],
      loading: false,
      modal: false
    };
    this.changeExpandedRowIds = this.changeExpandedRowIds.bind(this);
    autoBind(this);
  }

  componentDidMount() {
    if(this.state.data.length<=0 && !this.props.businessEntity){
      this.loadData();
    }else if(this.props.businessEntity){
      this.setState({
        data: this.props.businessEntity,
        loading: false
      });
    }
  }
  componentDidUpdate() {
    this.loadData();
    var eyeIcon = document.getElementsByClassName("oi-eye");
    if (eyeIcon.length && eyeIcon !== undefined) {
      eyeIcon[0].classList.add("glyphicon");
      eyeIcon[0].classList.add("glyphicon-eye-open");
    }
  }

  changeExpandedRowIds(expandedRowIds) {
    this.setState({ expandedRowIds });
  }

  loadData() {
    const { expandedRowIds, data, loading } = this.state;
    if (loading) {
      return;
    }

    const rowIdsWithNotLoadedChilds = [ROOT_ID, ...expandedRowIds].filter(
      rowId => data.findIndex(row => row.Parent_ID === rowId) === -1
    );

    if (rowIdsWithNotLoadedChilds.length) {
      if (loading) return;
      this.setState({ loading: true });

      Promise.all(
        rowIdsWithNotLoadedChilds.map((rowId) => {
          this.props.dispatch(topicsActions.fetchTopics(rowId)).then(loadedData => {
            this.setState({
              data: this.props.businessEntity,
              loading: false
            });
          });
          return true;
        }
        )
      );
        
    }
  }

  render() {
    if (!this.props.businessEntity) return this.renderLoading();
    return (
      <div className="container BusinessScreen">
      <div className="row firstRow">
        <div className="col-md-6">
        <h1>
            <Link to="/">
              <img src={"./imgs/MetLife.png"} alt="logo" className="mllogo" />
            </Link>{" "}
            RCSA Assistant
          </h1>
        </div>
        <div className="col-md-6" />
      </div>
        <div className="row">
          <hr />
          <br />
          <div className="col-md-12">
            <BusinessGrid currentState={this.state} onChangeExpandedRowIds={this.changeExpandedRowIds} onEntitySelection={this.onEntitySelection} businessEntity={this.props}/>
            <div className="row lastRow">
            <br />
              <hr />
              <div className="marLeft5">
                <Link to="/process" onClick={this.verifySelection} className="btn btn-success">
                <span className="glyphicon glyphicon-ok" aria-hidden="true" />
                </Link>
                <Link to="/" className="btn btn-danger">
                <span className="glyphicon glyphicon-remove" aria-hidden="true" />
                </Link>

                <Modal isOpen={this.state.modal} fade={false} toggle={this.toggle}>
                  <ModalHeader>ERROR !</ModalHeader>
                  <ModalBody>
                    <Alert color="danger">
                    Please select at least one Task Subject to proceed.
                    </Alert>
                  </ModalBody>
                  <ModalFooter>
                    <Button color="primary" onClick={this.toggle}>OK</Button>
                  </ModalFooter>
                </Modal>

              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  renderLoading() {
    return <p>Loading...</p>;
  }

  toggle() {
    this.setState({
      modal: !this.state.modal
    });
  }

  verifySelection(e){
    e.preventDefault();
    if(this.props.selectedEntityRows[0] === undefined || this.props.selectedEntityRows[0].length <= 0){
      //show error popup here
      this.toggle();
    }else
    {
      this.props.history.push('/process');
    }
  }
  // getIDfromRows(selectedRowIds, dataArray){
  //   let realIDs = [];
  //   console.log('selectedRowIds', selectedRowIds);
  //   console.log('dataArray', dataArray);
  //   selectedRowIds.forEach(element => {
  //     realIDs.push(dataArray[element].ID);
  //   });
  //   console.log('realIDs', realIDs);
  //   return realIDs;
  // }

  onEntitySelection(selection){
    // let newSelection = [];
    // selection.forEach(element => {
    //   newSelection.push(element-1);
    // });
    // console.log('selection', selection);
    // console.log('newSelection', newSelection);
    // let selectedEntityIDs = this.getIDfromRows(newSelection, this.props.businessEntity);
    this.props.dispatch(topicsActions.setSelectedEntityRows(selection));
    ////set selection in props...get that on next page
    ///and find child process on next page to make them selected.
  }

}

function mapStateToProps(state) {
  const [businessEntity] = topicsSelectors.getTopics(state);
  return {
    businessEntity,
    selectedEntityRows: topicsSelectors.getSelectedEntityRows(state)
  };
}

export default connect(mapStateToProps)(BusinessScreen);
