import _ from 'lodash';
import * as types from './actionTypes';
import Immutable from 'seamless-immutable';

const initialState = Immutable({
  postsById: undefined,
  currentFilter: 'all',
  currentPostId: undefined
});

export default function reduce(state = initialState, action = {}) {
  switch (action.type) {
    case types.POSTS_FETCHED:
      return state.merge({
        postsById: action.postsById
      });
    case types.FILTER_CHANGED:
      return state.merge({
        currentFilter: action.filter
      });
    case types.POST_SELECTED:
      return state.merge({
        currentPostId: action.postId
      });
    default:
      return state;
  }
}


export function getCurrentFilter(state) {
  return state.process.currentFilter;
}

export function getCurrentPost(state) {
  return _.get(state.process.postsById, state.process.currentPostId);
}
