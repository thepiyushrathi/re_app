// strings should be unique across reducers so namespace them with the reducer name

export const POSTS_FETCHED = 'process.POSTS_FETCHED';
export const FILTER_CHANGED = 'process.FILTER_CHANGED';
export const POST_SELECTED = 'process.POST_SELECTED';
