import _ from 'lodash';
import * as types from './actionTypes';
import Immutable from 'seamless-immutable';

const initialState = Immutable({
  businessEntity: undefined,
  selectedTopicUrls: [],
  selectionFinalized: false
});

export default function reduce(state = initialState, action = {}) {
  switch (action.type) {
    case types.TOPICS_FETCHED:
      return state.merge({
        businessEntity: action.businessEntity
      });
    case types.TOPICS_SELECTED:
      return state.merge({
        selectedTopicUrls: action.selectedTopicUrls
      });
    case types.TOPIC_SELECTION_FINALIZED:
      return state.merge({
        selectionFinalized: true
      });
    default:
      return state;
  }
}

// selectors

export function getTopics(state) {
  const businessEntity = state.business.businessEntity;
  return [businessEntity];
}

export function getSelectedTopicUrls(state) {
  return state.business.selectedTopicUrls;
}

export function getSelectedBusinessEntity(state) {
  return _.mapValues(_.keyBy(state.business.selectedTopicUrls), (topicUrl) => state.business.businessEntity[topicUrl]);
}

export function isTopicSelectionValid(state) {
  return state.business.selectedTopicUrls.length === 3;
}

export function isTopicSelectionFinalized(state) {
  return state.business.selectionFinalized;
}
