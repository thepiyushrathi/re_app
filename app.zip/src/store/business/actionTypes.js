// strings should be unique across reducers so namespace them with the reducer name

export const TOPICS_FETCHED = 'business.TOPICS_FETCHED';
export const TOPICS_SELECTED = 'business.TOPICS_SELECTED';
export const TOPIC_SELECTION_FINALIZED = 'business.TOPIC_SELECTION_FINALIZED';
