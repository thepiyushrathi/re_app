// containers are "smart" react components that are aware of redux
// they are connected to the redux store and listen on part of the app state
// they use mapStateToProps to specify which parts and use selectors to read them
// avoid having view logic & local component state in them, use "dumb" components instead

import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from "react-redux";
import "./ProcessScreen.css";
import * as postsActions from "../store/process/actions";
import * as postsSelectors from "../store/process/reducer";
import * as topicsSelectors from "../store/business/reducer";

import { Link } from "react-router-dom";
import ProcessGrid from '../components/ProcessGrid';
import RiskGrid from '../components/RiskGrid';
import ControlGrid from '../components/ControlGrid';

class ProcessScreen extends Component {
  constructor(props) {
    super(props);
    autoBind(this);
  }

  render() {
    return (
      <div className="container BusinessScreen fullWidth">
      <div className="row">
        <div className="col-md-6">
          <h1>
            <a href="index.html">
              <img src={"./imgs/MetLife.png"} alt="logo" className="mllogo" />
            </a>{" "}
            RCSA Assistant
          </h1>
        </div>
        <div className="col-md-6" />
      </div>
      <div className="ProcessScreen">
        <div className="row">
          <hr />
          <br />
          <div className="col-md-4">
            <h2>
              Process Selection
              <button
                type="button"
                className="btn btn-default btn-sm"
                data-toggle="modal"
                data-target="#myModalPrAdd"
              >
                <span className="glyphicon glyphicon-plus" aria-hidden="true" />
              </button>
            </h2>
            <ProcessGrid/>
          </div>
          <div className="col-md-4">
            <h2>
              Risk Selection
              <button
                type="button"
                className="btn btn-default btn-sm"
                data-toggle="modal"
                data-target="#myModalRskAdd"
              >
                <span className="glyphicon glyphicon-plus" aria-hidden="true" />
              </button>
            </h2>
            <RiskGrid/>
          </div>
          <div className="col-md-4">
            <h2>
              Control Selection
              <button
                type="button"
                className="btn btn-default btn-sm"
                data-toggle="modal"
                data-target="#myModalCtlAdd"
              >
                <span className="glyphicon glyphicon-plus" aria-hidden="true" />
              </button>
            </h2>
            <ControlGrid/>
            </div>
          </div>

              
          <div
            className="modal fade"
            id="myModalPrAdd"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="myModalLabel"
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <h4 className="modal-title" id="myModalLabel">
                    + Processes
                  </h4>
                </div>
                <div className="modal-body">
                  <form>
                    <div className="form-group">
                      <label htmlFor="exampleInputEmail1">
                        Enter the name of the Process:
                      </label>
                      <input
                        type="text"
                        className="form-control col-md-6"
                        id="exampleInputEmail1"
                        placeholder="P-00000"
                      />
                    </div>
                  </form>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-default"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div
            className="modal fade"
            id="myModalRskAdd"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="myModalLabel"
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <h4 className="modal-title" id="myModalLabel">
                    + Risks
                  </h4>
                </div>
                <div className="modal-body">
                  <form>
                    <div className="form-group">
                      <label htmlFor="exampleInputEmail1">
                        Enter the name of the Risk:
                      </label>
                      <input
                        type="text"
                        className="form-control col-md-6"
                        id="exampleInputEmail1"
                        placeholder="R-00000"
                      />
                    </div>
                  </form>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-default"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div
            className="modal fade"
            id="myModalCtlAdd"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="myModalLabel"
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <h4 className="modal-title" id="myModalLabel">
                    + Controls
                  </h4>
                </div>
                <div className="modal-body">
                  <form>
                    <div className="form-group">
                      <label htmlFor="exampleInputEmail1">
                        Enter the name of the Control:
                      </label>
                      <input
                        type="text"
                        className="form-control col-md-6"
                        id="exampleInputEmail1"
                        placeholder="C-00000"
                      />
                    </div>
                </form>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <br />
          <hr />
          <Link to="/process" className="btn btn-success">
                <span className="glyphicon glyphicon-ok" aria-hidden="true" />
                </Link>
                <Link to="/" className="btn btn-danger">
                <span
                  className="glyphicon glyphicon-remove"
                  aria-hidden="true"
                />
                </Link>
                </div>
      </div>
      </div>
    );
  }

  renderLoading() {
    return <p>Loading...</p>;
  }

  onFilterChanged(newFilter) {
    this.props.dispatch(postsActions.changeFilter(newFilter));
  }

  onRowClick(postId) {
    this.props.dispatch(postsActions.selectPost(postId));
  }
}

function mapStateToProps(state) {
  return {
    businessEntity: topicsSelectors.getSelectedBusinessEntity(state),
    currentFilter: postsSelectors.getCurrentFilter(state),
    currentPost: postsSelectors.getCurrentPost(state)
  };
}

export default connect(mapStateToProps)(ProcessScreen);
