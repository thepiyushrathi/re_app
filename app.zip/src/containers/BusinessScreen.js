import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from "react-redux";
import "./BusinessScreen.css";
import * as topicsActions from "../store/business/actions";
import * as topicsSelectors from "../store/business/reducer";

import Demo from "../components/Demo";
import { Link } from "react-router-dom";

class BusinessScreen extends Component {
  constructor(props) {
    super(props);
    autoBind(this);
  }

  componentDidMount() {
    this.props.dispatch(topicsActions.fetchTopics());
  }
  componentDidUpdate() {
    var test = document.getElementsByClassName("oi-eye");
    if (test != undefined) {
      console.log(test);
      test[0].classList.add("glyphicon");
      test[0].classList.add("glyphicon-eye-open");
    }
  }

  render() {
    console.log('gggggggggggggg',this.props);
    if (!this.props.businessEntity) return this.renderLoading();
    return (
      <div className="container BusinessScreen">
      <div className="row">
        <div className="col-md-6">
          <h1>
            <a href="index.html">
              <img src={"./imgs/MetLife.png"} alt="logo" className="mllogo" />
            </a>{" "}
            RCSA Assistant
          </h1>
        </div>
        <div className="col-md-6" />
      </div>
        <div className="row">
          <hr />
          <br />
          <div className="col-md-12">
            <Demo />
            <div className="row">
              <hr />
              <br />
                <Link to="/process" className="btn btn-success">
                <span className="glyphicon glyphicon-ok" aria-hidden="true" />
                </Link>
              <a href="index.html" className="btn btn-danger">
                <span
                  className="glyphicon glyphicon-remove"
                  aria-hidden="true"
                />
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  renderLoading() {
    return <p>Loading...</p>;
  }

}

function mapStateToProps(state) {
  const [businessEntity] = topicsSelectors.getTopics(state);
  return {
    businessEntity,
    selectedBusinessEntity: topicsSelectors.getSelectedBusinessEntity(state),
    canFinalizeSelection: topicsSelectors.isTopicSelectionValid(state)
  };
}

export default connect(mapStateToProps)(BusinessScreen);
