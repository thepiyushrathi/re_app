import * as React from "react";
import { Card } from "reactstrap";
import {
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";

import { process } from "../../public/processData.json";


export default class ProcessGrid extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      columns: [
        { name: "Name", title: "Name" },
        { name: "Description", title: "Description" },
        {
          name: "Start_Date",
          title: "Start Date",
          getCellValue: row => row.Start_Date.split("T")[0]
        },
        {
          name: "Due_Date",
          title: "Due Date",
          getCellValue: row => row.Due_Date.split("T")[0]
        }
      ],
      rows: process,
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
        { columnName: "Name", width: 100 },
        { columnName: "Description", width: 100 },
        { columnName: "Start_Date", width: 80 },
        { columnName: "Due_Date", width: 80 }
      ]
    };
  }

  render() {
    const {
      rows,
      columns,
      pageSizes,
      defaultColumnWidths
    } = this.state;

    console.log('aaaaaaaaaa', this.state);

    return (
      <Card>
        <Grid rows={rows} columns={columns}>

          <FilteringState />
          <SortingState />
          <SelectionState />
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table/>
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection for="Name" showSelectionControls showSelectAll />

          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
          
        </Grid>
      </Card>
    );
  }
}
