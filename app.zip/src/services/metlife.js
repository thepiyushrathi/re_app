//service to get data for business entity page.
import _ from 'lodash';

const SERVER_ENDPOINT = 'http://localhost:3000/';

class DataService {

  async getDefaultSubmetlifes() {
    const url = `${SERVER_ENDPOINT}/data.json`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Accept: 'application/json'
      }
    });
    if (!response.ok) {
      throw new Error(`getDefaultSubmetlifes failed, HTTP status ${response.status}`);
    }
    const data = await response.json();
    console.log(data);
    return data;
  }

  _validateUrl(url = '') {
    return url.startsWith('http') ? url : undefined;
  }

}

export default new DataService();
