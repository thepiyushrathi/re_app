import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from "react-redux";
// import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Alert } from 'reactstrap';

import { Link } from "react-router-dom";

class RiskAssesmentScreen extends Component {
  constructor(props) {
    super(props);
    autoBind(this);
  }

  // componentDidMount() {
  // }
  // componentDidUpdate() {
  // }

  render() {
    return (
      <div>
        <div className="container BusinessScreen">
          <div className="row firstRow">
            <div className="col-md-6">
              <h1>
            <Link to="/">
              <img src={"./imgs/MetLife.png"} alt="logo" className="mllogo" />
            </Link>{" "}
            RCSA Assistant
          </h1>
            </div>
            <div className="col-md-6" />
          </div>
          <hr />
          <br />
          <div className="row">
            <div className="col-md-12">
              <div className="form-group">
                <label>Guidance:</label>
                <input
                  type="text"
                  className="form-control"
                  id="exampleInputPassword1"
                  placeholder="Enter a description for this RCSA"
                />
              </div>
            </div>
          </div>
          <br />
          <div className="row">
            <div className="col-md-2">
              <div className="form-group">
                <label>Start Date:</label>
                <br />
                <button
                  type="button"
                  className="btn btn-default "
                  data-toggle="modal"
                  data-target="#myModalDateStart"
                >
                  <span
                    className="glyphicon glyphicon-calendar"
                    aria-hidden="true"
                  />
                </button>
              </div>
            </div>
            <div className="col-md-2">
              <div className="form-group">
                <label>End Date: </label>
                <br />
                <button
                  type="button"
                  className="btn btn-default"
                  data-toggle="modal"
                  data-target="#myModalDateEnd"
                >
                  <span
                    className="glyphicon glyphicon-calendar"
                    aria-hidden="true"
                  />
                </button>
              </div>
            </div>
          </div>
          <br />
          <br />
          <hr />
          <p className="lead">Ready to Submit?</p>
          <Link to="/results" className="btn btn-success">
            <span className="glyphicon glyphicon-ok" aria-hidden="true" />
          </Link>{" "}
          <a href="" className="btn btn-danger">
            <span className="glyphicon glyphicon-remove" aria-hidden="true" />
          </a>
        </div>

        <div
          className="modal fade"
          id="myModalDateStart"
          role="dialog"
          aria-labelledby="myModalLabel"
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">×</span>
                </button>
                <h4 className="modal-title" id="myModalLabel">
                  Select a Start Date:
                </h4>
              </div>
              <div className="modal-body">
                <p />
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Select
                </button>{" "}
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>

        <div
          className="modal fade"
          id="myModalDateEnd"
          role="dialog"
          aria-labelledby="myModalLabel"
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">×</span>
                </button>
                <h4 className="modal-title" id="myModalLabel">
                  Select an End Date:
                </h4>
              </div>
              <div className="modal-body">
                <p />
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Select
                </button>{" "}
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>

        <div
          className="modal fade"
          id="myModalUserRcsa"
          role="dialog"
          aria-labelledby="myModalLabel"
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">×</span>
                </button>
                <h4 className="modal-title" id="myModalLabel">
                  Select the RCSA Co-ordinator:
                </h4>
              </div>
              <div className="modal-body">
                <p />
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Select
                </button>{" "}
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>

        <div
          className="modal fade"
          id="myModalUserReview"
          role="dialog"
          aria-labelledby="myModalLabel"
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">×</span>
                </button>
                <h4 className="modal-title" id="myModalLabel">
                  Select the RCSA Reviewer:
                </h4>
              </div>
              <div className="modal-body">
                <p />
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Select
                </button>{" "}
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
  };
}

export default connect(mapStateToProps)(RiskAssesmentScreen);
