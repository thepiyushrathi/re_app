import _ from 'lodash';
import * as types from './actionTypes';
import dataService from '../../services/metlife';

export function fetchTopics(rowId) {
  return async(dispatch, getState) => {
    try {
      const submetlifeArray = await dataService.getLazyData(rowId);
      const businessEntity = submetlifeArray;
      console.log('businessEntitywwwwwwwwww', businessEntity);
      dispatch({ type: types.ENTITY_FETCHED, businessEntity });
      return businessEntity;
    } catch (error) {
      console.error(error);
    }
  };
}

export function setSelectedEntityRows(selectedEntityRows){
  return({ type: types.ENTITY_SELECTED, selectedEntityRows });
}
