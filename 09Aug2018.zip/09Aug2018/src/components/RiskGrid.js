import * as React from "react";
import { Card, UncontrolledTooltip } from "reactstrap";
import {
  DataTypeProvider,
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";


export default class RiskGrid extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      columns: [
        { name: "Resource_ID", title: "Resource ID" },
        { name: "Title", title: "Title" },
        {
          name: "Risk_Group",
          title: "Risk Group",
          getCellValue: row => row.Risk_Group.split("T")[0]
        },
        {
          name: "Risk_Category",
          title: "Risk Category",
          getCellValue: row => row.Risk_Category.split("T")[0]
        },
        {
          name: "Risk",
          title: "Risk"
        },
        {
          name: "Risk_Rating_Quarter",
          title: "Risk Rating Quarter",
          getCellValue: row => row.Risk_Rating_Quarter.split("T")[0]
        },
        {
          name: "Risk_Rating_Year",
          title: "Risk Rating Year",
          getCellValue: row => row.Risk_Rating_Year.split("T")[0]
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Owner",
          title: "Owner"
        }
      ],
      rows: this.props.riskData.riskFetched[0],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
      ],
      resourceHoverColumns:['Resource_ID']
    };
  }

  render() {
    const {
      rows,
      columns,
      pageSizes,
      defaultColumnWidths,
      resourceHoverColumns
    } = this.state;

    const HoverFormatter = ({ row }) => (
      <div
        style={{
          display: 'flex',
        }}
      >
      {findChilds(row.ID, this.props.riskData.controlFetched[0]).length > 0 ?
      <div>
        <a className="anchorDecoration" id={'risk'+this.props.riskData.riskFetched[0].find(e => e.ID === row.ID).ID}>
          {this.props.riskData.riskFetched[0].find(e => e.ID === row.ID).Resource_ID}
        </a>
        <UncontrolledTooltip placement="right" target={'risk'+this.props.riskData.riskFetched[0].find(e => e.ID === row.ID).ID}>
          <ul className="childList">
          {
            findChilds(row.ID, this.props.riskData.controlFetched[0]).map(function(item, i){
              return <li key={i}>{item.Resource_ID}</li>
            })
          }
          </ul>
        </UncontrolledTooltip>
        </div>
        :
        <div>
        <a id={'risk'+this.props.riskData.riskFetched[0].find(e => e.ID === row.ID).ID}>
          {this.props.riskData.riskFetched[0].find(e => e.ID === row.ID).Resource_ID}
        </a>
        </div>
      }
        
      </div>
    );

    function findChilds(ID, dataArray){
      let selectChilds = [];
      dataArray.forEach(element => {
        if(element.Risk_ID === ID){
          selectChilds.push(element);
        }
      });
      return selectChilds;
    }

    function getSelectedRiskRows(classObj) {
      let selectedRiskRows =[];
      if(classObj.props.riskData.selectedRiskRows[0] !== undefined){
        selectedRiskRows = classObj.props.riskData.selectedRiskRows[0];
      }
        return selectedRiskRows;
      }
    return (
      <Card>
        <Grid rows={rows} columns={columns}>
        <DataTypeProvider
            for={resourceHoverColumns}
            formatterComponent={HoverFormatter}
          />
          <FilteringState />
          <SortingState />
          <SelectionState selection={getSelectedRiskRows(this)} onSelectionChange={this.props.onRiskSelectionChange}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table/>
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection  for="Resource_ID" showSelectionControls showSelectAll />
          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
          
        </Grid>
      </Card>
    );
  }
}
