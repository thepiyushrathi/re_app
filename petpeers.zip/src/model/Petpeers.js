export const Petpeers = {
    userDetail : [
        {
            "userId" : 1,
            "username" : "a",
            "password" : "a"
        },
        {
            "userId" : 2,
            "username" : "b",
            "password" : "b"
        }
    ],
    petDetail : [
        {
            "petId" : 1,
            "userId" : 1,
            "name" : "rocky",
            "age" : 4,
            "place" : "IN"
        },
        {
            "petId" : 2,
            "userId" : 1,
            "name" : "milo",
            "age" : 3,
            "place" : "CH"
        },
        {
            "petId" : 3,
            "userId" : 1,
            "name" : "Leo",
            "age" : 2,
            "place" : "JP"
        },
        {
            "petId" : 4,
            "userId" : 2,
            "name" : "lucy",
            "age" : 1,
            "place" : "US"
        },
        {
            "petId" : 5,
            "userId" : 1,
            "name" : "luna",
            "age" : 2,
            "place" : "CN"
        },
        {
            "petId" : 6,
            "userId" : 1,
            "name" : "lily",
            "age" : 5,
            "place" : "BG"
        }
    ]
};