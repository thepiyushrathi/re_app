import React from "react";
import { Link } from "react-router-dom";
import {connect} from "react-redux";
//import { Petpeers } from '../model/Petpeers';
import { buyThisPet } from "../actions/indexAction";
import Advancesearch from './Advancesearch';

class Petlist extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showPopup: false
        };
  
        //this.buyPet = this.buyPet.bind(this);
    }

    togglePopup() {
        this.setState({
          showPopup: !this.state.showPopup
        });
    }

    buyPet(indexId,currUserId) {
        //event.preventDefault();
        //alert(event.target.value);
        /*--Use Axios to send data to server--*/
        alert("Pet Sold");
        //alert(event.target.value);
        this.props.dispatch(buyThisPet(indexId,currUserId));
    }

    render() {
        this.numRows = 1;        
        return (
            <div>
                <div className="maincontainer">
                    <h2>All Pet List</h2>
                    <span><a href="javascript:void(0);" onClick={this.togglePopup.bind(this)}>Advance Search</a></span>
                </div>
                <div className="container">
                    <table border="1" width="80%" cellSpacing="0"><tbody>
                        <tr>
                            <td>#</td>
                            <td>Pet Name (Up/Down)</td>
                            <td>Place</td>
                            <td>Age</td>
                            <td>UserId</td>
                            <td>Action</td>
                        </tr>
                        {this.props.allPets.map((val,index) => 
                            <tr>
                                <td>{ this.numRows++ }</td>
                                <td><Link to={`/pets/${val.petId}`}>{val.name}</Link></td>
                                <td>{val.place}</td>
                                <td>{val.age}</td>
                                <td>{val.userId}</td>
                                <td>
                                    {
                                        (sessionStorage.getItem('key-petpeers-userId') == val.userId) ? 
                                        (<button className="disablebutton">Sold</button>) :  
                                        (<button type="button" value={index} className="buybtn" onClick={ () => this.buyPet(index,sessionStorage.getItem('key-petpeers-userId')) }>Buy</button>)
                                    }
                                </td>
                            </tr>)  
                        }
                    </tbody></table>
                      
                    {this.state.showPopup ? 
                          <Advancesearch text='Close Me' closePopup={this.togglePopup.bind(this)} />
                            : null
                    }
                    
                    <div className="paging">
                        Prev 1 2 3 Next
                    </div>
                </div>
            </div>
        )
    }    
}

//Map State from store to props
const mapStateToProps = (state) => {
    return { allPets : state.getSelDetailReducer.petDetail }
};

export default connect(mapStateToProps) (Petlist);


/*mapDispatchToProps: It connects redux actions to react props
With mapDispatchToProps every action creator wrapped into a dispatch call so they may be invoked directly, will be merged into the component’s props.
function mapStateToProps(state) {
  return { todos: state.todos }
}
function mapDispatchToProps(dispatch) {
  return { addTodo: bindActionCreators(addTodo, dispatch) }
}
export default connect(mapStateToProps, mapDispatchToProps)(Todos);*/


