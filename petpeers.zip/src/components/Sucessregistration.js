import React from "react";
import { Link } from 'react-router-dom'

const Sucessregistration = () => <div className="maincontainer"><h2>User Registration</h2><div className="container">You are successfully registered. Please <Link to="/login">Sign In</Link></div></div>

export default Sucessregistration;