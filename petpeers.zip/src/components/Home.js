import React from "react";

const Home = () => <div className="maincontainer"><h2>Home </h2></div>

export default Home;