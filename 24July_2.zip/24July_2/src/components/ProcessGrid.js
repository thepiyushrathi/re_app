import * as React from "react";
import autoBind from "react-autobind";
import { Card } from "reactstrap";
import {
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility,
  TableBandHeader
} from "@devexpress/dx-react-grid-bootstrap4";

export default class ProcessGrid extends React.PureComponent {
  constructor(props) {
    super(props);
    autoBind(this);

    this.state = {
      columns: [
        { name: "Resource_ID", 
        title: "Resource ID" ,
        getCellValue: row => row.Resource_ID.split("T")[0] },
        { name: "Title", title: "Title" },
        {
          name: "Process_Category",
          title: "Process Category"
        },
        {
          name: "Process",
          title: "Process"
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Process_Owner",
          title: "Process Owner"
        }
      ],
      rows: this.props.processData.processFetched[0],
      pageSizes: [5, 10, 20],
      columnBands: [
        {
          title: 'System Fields',
          children: [
            { columnName: 'Resource_ID' },
            { columnName: 'Title' }
          ],
        },
        {
          title: 'ML-Process',
          children: [
            { columnName: 'Process_Category' },
            { columnName: 'Process' }
          ],
        },
        {
          title: 'OPSS-Process',
          children: [
            { columnName: 'Scope' },
            { columnName: 'Process_Owner' }
          ],
        }
      ],
      defaultColumnWidths: [
        { columnName: "Resource_ID", width: 150 },
        { columnName: "Title", width: 150 },
        { columnName: "Process_Category", width: 150 },
        { columnName: "Process", width: 150 },
        { columnName: "Scope", width: 150 },
        { columnName: "Process_Owner", width: 150 }
      ]
    };
  }

  render() {
    const {
      rows,
      columns,
      pageSizes,
      columnBands,
      defaultColumnWidths
    } = this.state;

    console.log('PROPS in PROCESS_GRID',this.props);
    
    function getSelectedProcessRows(classObj) {
      let selectedProcessRows =[];
      if(classObj.props.processData.selectedProcessRows[0] != undefined){
        selectedProcessRows = classObj.props.processData.selectedProcessRows[0];
      }
      return selectedProcessRows;
    }

    return (
      <Card>
        <Grid rows={rows} columns={columns}>

          <FilteringState />
          <SortingState />
          <SelectionState selection={getSelectedProcessRows(this)} onSelectionChange= {this.props.onSelectionChange}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table/>
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection for="Resource_ID" showSelectionControls showSelectAll />
          <TableBandHeader
            columnBands={columnBands}
          />
          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
          
        </Grid>
      </Card>
    );
  }
}
