import _ from 'lodash';
import * as types from './actionTypes';
import dataService from '../../services/metlife';

export function fetchProcess() {
  return async(dispatch, getState) => {
    try {
      const processArray = await dataService.getProcessData();
      dispatch({ type: types.PROCESS_FETCHED, processArray });
    } catch (error) {
      console.error(error);
    }
  };
}

export function setSelectedProcessRows(selectedProcessRows){
  return({ type: types.PROCESS_SELECTED, selectedProcessRows });
}

export function setSelectedRiskRows(selectedRiskRows){
  console.log('setSelectedRiskRows', selectedRiskRows);
  return({ type: types.RISK_SELECTED, selectedRiskRows });
}

export function setSelectedControlRows(selectedControlRows){
  console.log('setSelectedControlRows', selectedControlRows);
  return({ type: types.CONTROL_SELECTED, selectedControlRows });
}