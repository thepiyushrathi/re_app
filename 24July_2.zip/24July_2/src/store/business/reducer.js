import _ from 'lodash';
import * as types from './actionTypes';
import Immutable from 'seamless-immutable';

const initialState = Immutable({
  businessEntity: undefined,
  selectedEntityRows: undefined,
  selectionFinalized: false
});

export default function reduce(state = initialState, action = {}) {
  switch (action.type) {
    case types.ENTITY_FETCHED:
      return Object.assign({}, state,{
        businessEntity: action.businessEntity
      });
    case types.ENTITY_SELECTED:
      return Object.assign({}, state,{
        selectedEntityRows: action.selectedEntityRows
      });
    default:
      return state;
  }
}

// selectors

export function getTopics(state) {
  const businessEntity = state.business.businessEntity;
  return [businessEntity];
}

export function getSelectedEntityRows(state) {
  const selectedEntityRows = state.business.selectedEntityRows;
  console.log('getSelectedEntityRows', selectedEntityRows);
  return [selectedEntityRows];
}

export function isEntitySelectionFinalized(state) {
  return state.business.selectionFinalized;
}
