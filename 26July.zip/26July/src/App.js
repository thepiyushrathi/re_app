import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as topicsSelectors from './store/business/reducer';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import '@devexpress/dx-react-grid-bootstrap4/dist/dx-react-grid-bootstrap4.css';
import Root from './components/Root'

class App extends Component {
  render() {
    return (
      <div className="App">
      <Root/>
      </div>
    );
  }
}

// which props do we want to inject, given the global store state?
function mapStateToProps(state) {
  return {
    isSelectionFinalized: topicsSelectors.isEntitySelectionFinalized(state)
  };
}

export default connect(mapStateToProps)(App);
