import * as React from "react";
import { Card } from "reactstrap";
import {
  TreeDataState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  CustomTreeData,
  IntegratedFiltering,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  Table,
  TableHeaderRow,
  TableTreeColumn,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility,
  ColumnChooser
} from "@devexpress/dx-react-grid-bootstrap4";

const getChildRows = (row, rows) => {
  const childRows = rows.filter(r => r.Parent_ID === (row ? row.ID : 0));
  return childRows.length ? childRows : null;
};


export default class BusinessGrid extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      columns: [
        { name: "Subject", title: "Task Subject" },
        { name: "Status", title: "Status" },
        {
          name: "Start_Date",
          title: "Start Date",
          getCellValue: row => row.Start_Date.split("T")[0]
        },
        {
          name: "Due_Date",
          title: "Due Date",
          getCellValue: row => row.Due_Date.split("T")[0]
        }
      ],
      rows: this.props.businessEntity.businessEntity,
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
      ],
      defaultHiddenColumnNames: []
    };
  }

  render() {
    const {
      rows,
      columns,
      pageSizes,
      defaultColumnWidths,
      defaultHiddenColumnNames
    } = this.state;

    return (
      <Card>
        <Grid rows={rows} columns={columns}>

          <TreeDataState />
          <FilteringState />
          <SortingState />
          <SelectionState onSelectionChange={this.props.onEntitySelection}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <CustomTreeData getChildRows={getChildRows} />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table />
          <TableColumnVisibility
            defaultHiddenColumnNames={defaultHiddenColumnNames}
          />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableTreeColumn for="Subject" showSelectionControls showSelectAll />

          <Toolbar />
          <ColumnChooser />

          <PagingPanel pageSizes={pageSizes} />
        </Grid>
      </Card>
    );
  }
}
