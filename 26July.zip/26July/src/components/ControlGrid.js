import * as React from "react";
import { Card } from "reactstrap";
import {
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";

export default class ControlGrid extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      columns: [
        { name: "Resource_ID", title: "Resource ID" },
        { name: "Title", title: "Title" },
        {
          name: "Control_Group",
          title: "Control Group",
          getCellValue: row => row.Control_Group.split("T")[0]
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Control_Owner",
          title: "Control Owner"
        }
      ],
      rows: this.props.controlData.controlFetched[0],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
      ]
    };
  }

  render() {
    const { rows, columns, pageSizes, defaultColumnWidths } = this.state;

    function getSelectedControlRows(classObj) {
      let selectedControlRows = [];
      if (classObj.props.controlData.selectedControlRows[0] !== undefined) {
        selectedControlRows = classObj.props.controlData.selectedControlRows[0];
      }
      return selectedControlRows;
    }

    return (
      <Card>
        <Grid rows={rows} columns={columns}>
          <FilteringState />
          <SortingState />
          <SelectionState selection={getSelectedControlRows(this)} />
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table />
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection
            for="Resource_ID"
            showSelectionControls
            showSelectAll
          />

          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
        </Grid>
      </Card>
    );
  }
}
