import * as React from "react";
import autoBind from "react-autobind";
import { Card,UncontrolledTooltip } from "reactstrap";
import {
  DataTypeProvider,
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";

export default class ProcessGrid extends React.PureComponent {
  constructor(props) {
    super(props);
    autoBind(this);

    this.state = {
      columns: [
        { name: "Resource_ID", 
        title: "Resource ID" ,
        getCellValue: row => row.Resource_ID.split("T")[0] },
        { name: "Title", title: "Title" },
        {
          name: "Process_Category",
          title: "Process Category"
        },
        {
          name: "Process",
          title: "Process"
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Process_Owner",
          title: "Process Owner"
        }
      ],
      rows: this.props.processData.processFetched[0],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
      ],
      resourceHoverColumns:['Resource_ID']
    };
  }

  render() {
    const {
      rows,
      columns,
      pageSizes,
      defaultColumnWidths,
      resourceHoverColumns
    } = this.state;

    const HoverFormatter = ({ row }) => (
      <div
        style={{
          display: 'flex',
        }}
      >
      {findChilds(row.ID, this.props.processData.riskFetched[0]).length > 0 ?
      <div>
        <a className="anchorDecoration" id={'process'+this.props.processData.processFetched[0].find(e => e.ID === row.ID).ID}>
          {this.props.processData.processFetched[0].find(e => e.ID === row.ID).Resource_ID}
        </a>
        <UncontrolledTooltip placement="right" target={'process'+this.props.processData.processFetched[0].find(e => e.ID === row.ID).ID}>
          <ul className="childList">
          {
            findChilds(row.ID, this.props.processData.riskFetched[0]).map(function(item, i){
              return <li key={i}>{item.Resource_ID}</li>
            })
          }
          </ul>
        </UncontrolledTooltip>
        </div>
        :
        <div>
        <a id={'process'+this.props.processData.processFetched[0].find(e => e.ID === row.ID).ID}>
          {this.props.processData.processFetched[0].find(e => e.ID === row.ID).Resource_ID}
        </a>
        </div>
      }
        
      </div>
    );

    function findChilds(ID, dataArray){
      let selectChilds = [];
      dataArray.forEach(element => {
        if(element.Process_ID === ID){
          selectChilds.push(element);
        }
      });
      return selectChilds;
    }
    
    function getSelectedProcessRows(classObj) {
      let selectedProcessRows =[];
      if(classObj.props.processData.selectedProcessRows[0] !== undefined){
        selectedProcessRows = classObj.props.processData.selectedProcessRows[0];
      }
      return selectedProcessRows;
    }

    return (
      <Card>
        <Grid rows={rows} columns={columns}>
        <DataTypeProvider
            for={resourceHoverColumns}
            formatterComponent={HoverFormatter}
          />
          <FilteringState />
          <SortingState />
          <SelectionState selection={getSelectedProcessRows(this)} onSelectionChange={this.props.onSelectionChange}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table/>
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection for="Resource_ID" showSelectionControls showSelectAll />
          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
          
        </Grid>
      </Card>
    );
  }
}
