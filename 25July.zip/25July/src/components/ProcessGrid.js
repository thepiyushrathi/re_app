import * as React from "react";
import autoBind from "react-autobind";
import { Card } from "reactstrap";
import {
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";

export default class ProcessGrid extends React.PureComponent {
  constructor(props) {
    super(props);
    autoBind(this);

    this.state = {
      columns: [
        { name: "Resource_ID", 
        title: "Resource ID" ,
        getCellValue: row => row.Resource_ID.split("T")[0] },
        { name: "Title", title: "Title" },
        {
          name: "Process_Category",
          title: "Process Category"
        },
        {
          name: "Process",
          title: "Process"
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Process_Owner",
          title: "Process Owner"
        }
      ],
      rows: this.props.processData.processFetched[0],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
      ]
    };
  }

  render() {
    const {
      rows,
      columns,
      pageSizes,
      defaultColumnWidths
    } = this.state;

    
    function getSelectedProcessRows(classObj) {
      let selectedProcessRows =[];
      if(classObj.props.processData.selectedProcessRows[0] !== undefined){
        selectedProcessRows = classObj.props.processData.selectedProcessRows[0];
      }
      return selectedProcessRows;
    }

    return (
      <Card>
        <Grid rows={rows} columns={columns}>

          <FilteringState />
          <SortingState />
          <SelectionState selection={getSelectedProcessRows(this)} onSelectionChange={this.props.onSelectionChange}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table/>
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection for="Resource_ID" showSelectionControls showSelectAll />
          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
          
        </Grid>
      </Card>
    );
  }
}
