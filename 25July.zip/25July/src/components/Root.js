import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import ProcessScreen from "../containers/ProcessScreen";
import BusinessScreen from "../containers/BusinessScreen";

const Root = () => (
    <Router>
      <Switch>
        <Route exact path="/" component={BusinessScreen} />
        <Route exact path="/process" component={ProcessScreen} />
      </Switch>
    </Router>
);
export default Root;
