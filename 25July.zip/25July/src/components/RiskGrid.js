import * as React from "react";
import { Card } from "reactstrap";
import {
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";


export default class RiskGrid extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      columns: [
        { name: "Resource_ID", title: "Resource ID" },
        { name: "Title", title: "Title" },
        {
          name: "Risk_Group",
          title: "Risk Group",
          getCellValue: row => row.Risk_Group.split("T")[0]
        },
        {
          name: "Risk_Category",
          title: "Risk Category",
          getCellValue: row => row.Risk_Category.split("T")[0]
        },
        {
          name: "Risk",
          title: "Risk"
        },
        {
          name: "Risk_Rating_Quarter",
          title: "Risk Rating Quarter",
          getCellValue: row => row.Risk_Rating_Quarter.split("T")[0]
        },
        {
          name: "Risk_Rating_Year",
          title: "Risk Rating Year",
          getCellValue: row => row.Risk_Rating_Year.split("T")[0]
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Owner",
          title: "Owner"
        }
      ],
      rows: this.props.riskData.riskFetched[0],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
      ]
    };
  }

  render() {
    const {
      rows,
      columns,
      pageSizes,
      defaultColumnWidths
    } = this.state;

    function getSelectedRiskRows(classObj) {
      let selectedRiskRows =[];
      if(classObj.props.riskData.selectedRiskRows[0] !== undefined){
        selectedRiskRows = classObj.props.riskData.selectedRiskRows[0];
      }
        return selectedRiskRows;
      }
    return (
      <Card>
        <Grid rows={rows} columns={columns}>

          <FilteringState />
          <SortingState />
          <SelectionState selection={getSelectedRiskRows(this)} onSelectionChange={this.props.onRiskSelectionChange}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table/>
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection  for="Resource_ID" showSelectionControls showSelectAll />
          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
          
        </Grid>
      </Card>
    );
  }
}
