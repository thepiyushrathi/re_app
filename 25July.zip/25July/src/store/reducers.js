import business from './business/reducer';
import process from './process/reducer';

export {
  business,
  process
};
