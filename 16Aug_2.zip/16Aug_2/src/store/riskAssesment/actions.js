import _ from 'lodash';
import * as types from './actionTypes';
import dataService from '../../services/metlife';
import moment from "moment";

export function postPRC(currentState, allProps) {
  return async(dispatch, getState) => {
    try {
      const guidanceData = {
        guidance : currentState.guidance,
        startDate : moment(currentState.startDate).format('ll'),
        endDate : moment(currentState.endDate).format('ll')
      };
      const sendData = {
        guidanceData : guidanceData,
        selectedControlRows : allProps.selectedControlRows,
        selectedEntityRows : allProps.selectedEntityRows,
        selectedProcessRows : allProps.selectedProcessRows,
        selectedRiskRows : allProps.selectedRiskRows,
      }
      const raData = await dataService.getRaData(sendData);
      dispatch({ type: types.RA_FETCHED, raData });
    } catch (error) {
      console.error(error);
    }
  };
}

export function setPRCGuidance(currentState){
  const guidanceData = {
    guidance : currentState.guidance,
    startDate : moment(currentState.startDate).format('ll'),
    endDate : moment(currentState.endDate).format('ll')
  };
  return({ type: types.PRC_SUBMIT, guidanceData });
}
