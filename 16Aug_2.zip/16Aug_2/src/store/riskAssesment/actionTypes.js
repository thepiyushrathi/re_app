// strings should be unique across reducers so namespace them with the reducer name

export const PRC_SUBMIT = 'riskAssesment.PRC_SUBMIT';
export const RA_FETCHED = 'riskAssesment.RA_FETCHED';
