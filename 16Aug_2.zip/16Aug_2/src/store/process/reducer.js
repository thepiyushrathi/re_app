import _ from 'lodash';
import * as types from './actionTypes';
import Immutable from 'seamless-immutable';

const initialState = Immutable({
  processFetched: undefined,
  riskFetched: [],
  controlFetched: [],
  selectedProcessRows: undefined,
  selectedRiskRows: undefined,
  selectedControlRows: undefined
});

export default function reduce(state = initialState, action = {}) {
  switch (action.type) {
    case types.PROCESS_FETCHED:
      return Object.assign({}, state,{
        processFetched: action.processArray,
        // riskFetched: action.processArray.risk,
        // controlFetched: action.processArray.control
      });
    case types.RISK_FETCHED:
    console.log('action.riskArray', action.riskArray);
      return Object.assign({}, state,{
        riskFetched: action.riskArray
      });
      // if(state.riskFetched){
      //   const mergeState = [...state.riskFetched, ...action.riskArray];
        
      //   return Object.assign({}, state,{
      //     riskFetched: mergeState,
      //   });
      // }else{
      //   return Object.assign({}, state,{
      //     riskFetched: action.businessEntity,
      //   });
      // }
    case types.CONTROL_FETCHED:
      return Object.assign({}, state,{
        controlFetched: action.controlArray,
      });
      // if(state.controlFetched){
      //   const mergeState = [...state.controlFetched, ...action.controlArray];
        
      //   return Object.assign({}, state,{
      //     controlFetched: mergeState,
      //   });
      // }else{
      //   return Object.assign({}, state,{
      //     controlFetched: action.controlArray,
      //   });
      // }
    case types.PROCESS_SELECTED:
      return Object.assign({}, state,{
        selectedProcessRows: action.selectedProcessRows
      });
      case types.RISK_SELECTED:
      return Object.assign({}, state,{
        selectedRiskRows: action.selectedRiskRows
      });
      case types.CONTROL_SELECTED:
      return Object.assign({}, state,{
        selectedControlRows: action.selectedControlRows
      });
    default:
      return state;
  }
}

export function getProcessFetched(state) {
  const processFetched = state.process.processFetched;
  return [processFetched];
}
export function getRiskFetched(state) {
  const riskFetched = state.process.riskFetched;
  return [riskFetched];
}
export function getControlFetched(state) {
  const controlFetched = state.process.controlFetched;
  return [controlFetched];
}

export function getSelectedProcessRows(state) {
  const selectedProcessRows = state.process.selectedProcessRows;
  return [selectedProcessRows];
}

export function getSelectedRiskRows(state) {
  const selectedRiskRows = state.process.selectedRiskRows;
  return [selectedRiskRows];
}

export function getSelectedControlRows(state) {
  const selectedControlRows = state.process.selectedControlRows;
  return [selectedControlRows];
}
