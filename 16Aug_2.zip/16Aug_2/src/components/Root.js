import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import ProcessScreen from "../containers/ProcessScreen";
import BusinessScreen from "../containers/BusinessScreen";
import RiskAssesmentScreen from "../containers/RiskAssesmentScreen";
import ResultsScreen from "../containers/ResultsScreen";

const Root = () => (
  <Router>
    {/* // <Router basename={'/reactApp'}> */}
      <Switch>
        <Route exact path="/" component={BusinessScreen} />
        <Route exact path="/process" component={ProcessScreen} />
        <Route exact path="/riskassesment" component={RiskAssesmentScreen} />
        <Route exact path="/results" component={ResultsScreen} />
      </Switch>
    </Router>
);
export default Root;
