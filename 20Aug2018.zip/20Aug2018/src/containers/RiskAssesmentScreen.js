import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from "react-redux";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Alert } from 'reactstrap';
import * as raActions from "../store/riskAssesment/actions";
import * as raReducer from "../store/riskAssesment/reducer";
// import * as postsActions from "../store/process/actions";
import * as postsSelectors from "../store/process/reducer";
import * as topicsSelectors from "../store/business/reducer";
import { Link } from "react-router-dom";
import RiskAssesment from '../components/RiskAssesment';
import DateModal from '../components/DateModal';
// import moment from "moment";

class RiskAssesmentScreen extends Component {
  constructor(props) {
    super(props);
    autoBind(this);
    this.state = {
      startDate: undefined,
      endDate: undefined,
      guidance: '',
      year: '',
      quater: '',
      modal: false,
      validationErrors : []
    };
    this.handleChangeStart = this.handleChangeStart.bind(this);
    this.handleChangeEnd = this.handleChangeEnd.bind(this);
  }

  handleChangeStart(date) {
    this.setState({
      startDate: date
    });
  }

  handleChangeEnd(date) {
    this.setState({
      endDate: date
    });
  }

  handleChangeGuidance(value) {
    this.setState({
      guidance: value
    });
  }

  handleChangeYear(value) {
    this.setState({
      year: value
    });
  }

  handleChangeQuarter(value) {
    this.setState({
      quater: value
    });
  }

  handleSubmit(){
    let validationErrors = [];
    if(this.state.guidance === '' || this.state.guidance === undefined){
      validationErrors.push(1);
    }
    if(this.state.year === '' || this.state.year === undefined){
      validationErrors.push(2);
    }
    if(this.state.quater === '' || this.state.quater === undefined){
      validationErrors.push(3);
    }
    if(this.state.startDate === '' || this.state.startDate === undefined){
      validationErrors.push(4);
    }
    if(this.state.endDate === '' || this.state.endDate === undefined){
      validationErrors.push(5);
    }
    if(validationErrors.length<=0){
      this.props.dispatch(raActions.setPRCGuidance(this.state));
      this.props.history.push('/process');
    }else{
      this.setState({
        validationErrors: validationErrors
      });
      this.toggle();
    }

  }

  toggle() {
    this.setState({
      modal: !this.state.modal
    });
  }

  // componentDidMount() {
  // }
  // componentDidUpdate() {
  // }

  render() {
    return (
      <div>
        <div className="container BusinessScreen">
          <div className="row firstRow">
            <div className="col-md-6">
              <h1>
            <Link to="/">
              <img src={"./imgs/MetLife.png"} alt="logo" className="mllogo" />
            </Link>{" "}
            RCSA Assistant
          </h1>
            </div>
            <div className="col-md-6" />
          </div>
          <hr />
          <br />
          <RiskAssesment parentState={this.state} handleChangeQuarter={this.handleChangeQuarter} handleChangeYear={this.handleChangeYear} handleChangeGuidance={this.handleChangeGuidance} handleSubmit={this.handleSubmit}/>
        </div>
        <DateModal currentState={this.state} handleChangeEnd={this.handleChangeEnd} handleChangeStart={this.handleChangeStart}/>

        <Modal isOpen={this.state.modal} fade={false} toggle={this.toggle}>
          <ModalHeader>ERROR !</ModalHeader>
          <ModalBody>
            {
              this.state.validationErrors.map(function(item, i){
                if(item === 1){
                  return <Alert color="danger" key={item}>
                  Please enter a description for RCSA.
                  </Alert>
                }
                if(item === 2){
                  return <Alert color="danger" key={item}>
                  Please select year.
                  </Alert>
                }
                if(item === 3){
                  return <Alert color="danger" key={item}>
                  Please select quater.
                  </Alert>
                }
                if(item === 4){
                  return <Alert color="danger" key={item}>
                  Please select start date.
                  </Alert>
                }
                if(item === 5){
                  return <Alert color="danger" key={item}>
                  Please select end date.
                  </Alert>
                }
                return '';
              })
            }
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.toggle}>OK</Button>
          </ModalFooter>
        </Modal>

      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    selectedEntityRows: topicsSelectors.getSelectedEntityRows(state),
    selectedProcessRows: postsSelectors.getSelectedProcessRows(state),
    selectedRiskRows: postsSelectors.getSelectedRiskRows(state),
    selectedControlRows: postsSelectors.getSelectedControlRows(state),
    guidanceData : raReducer.getGuidanceData(state)
  };
}

export default connect(mapStateToProps)(RiskAssesmentScreen);
