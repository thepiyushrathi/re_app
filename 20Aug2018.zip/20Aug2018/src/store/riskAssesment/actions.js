import _ from 'lodash';
import * as types from './actionTypes';
import moment from "moment";

export function setPRCGuidance(currentState){
  const guidanceData = {
    guidance : currentState.guidance,
    year : currentState.year,
    quater : currentState.quater,
    startDate : moment(currentState.startDate).format('ll'),
    endDate : moment(currentState.endDate).format('ll')
  };
  return({ type: types.PRC_SUBMIT, guidanceData });
}
