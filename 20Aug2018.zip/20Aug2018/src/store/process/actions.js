import _ from 'lodash';
import * as types from './actionTypes';
import dataService from '../../services/metlife';

export function fetchProcess(selectedEntities) {
  return async(dispatch, getState) => {
    try {
      const processArray = await dataService.getProcessData(selectedEntities);
      dispatch({ type: types.PROCESS_FETCHED, processArray });
    } catch (error) {
      console.error(error);
    }
  };
}

export function fetchRisk(processID) {
  return async(dispatch, getState) => {
    try {
      const riskArray = await dataService.getRiskDataService(processID);
      dispatch({ type: types.RISK_FETCHED, riskArray });
    } catch (error) {
      console.error(error);
    }
  };
}

export function fetchControl(riskID) {
  return async(dispatch, getState) => {
    try {
      const controlArray = await dataService.getControlDataService(riskID);
      dispatch({ type: types.CONTROL_FETCHED, controlArray });
    } catch (error) {
      console.error(error);
    }
  };
}

export function postPRC(allProps) {
  return async(dispatch, getState) => {
    try {
      const sendData = {
        guidanceData : allProps.guidanceData,
        selectedControlRows : allProps.selectedControlRows,
        selectedEntityRows : allProps.selectedEntityRows,
        selectedProcessRows : allProps.selectedProcessRows,
        selectedRiskRows : allProps.selectedRiskRows,
      }
      const raData = await dataService.getRaData(sendData);
      console.log('raDatawwwwwwwwwwww', raData);
      dispatch({ type: types.RA_FETCHED, raData });
    } catch (error) {
      console.error(error);
    }
  };
}

export function setSelectedProcessRows(selectedProcessRows){
  return({ type: types.PROCESS_SELECTED, selectedProcessRows });
}

export function setSelectedRiskRows(selectedRiskRows){
  return({ type: types.RISK_SELECTED, selectedRiskRows });
}

export function setSelectedControlRows(selectedControlRows){
  return({ type: types.CONTROL_SELECTED, selectedControlRows });
}