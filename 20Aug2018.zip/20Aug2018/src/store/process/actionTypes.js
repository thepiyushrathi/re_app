// strings should be unique across reducers so namespace them with the reducer name

export const PROCESS_FETCHED = 'process.PROCESS_FETCHED';
export const RISK_FETCHED = 'process.RISK_FETCHED';
export const CONTROL_FETCHED = 'process.CONTROL_FETCHED';
export const PROCESS_SELECTED = 'process.PROCESS_SELECTED';
export const RISK_SELECTED = 'process.RISK_SELECTED';
export const CONTROL_SELECTED = 'process.CONTROL_SELECTED';
export const RA_FETCHED = 'process.RA_FETCHED';
