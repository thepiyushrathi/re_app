import * as React from "react";
import autoBind from "react-autobind";
// import { Link } from "react-router-dom";
import moment from "moment";

export default class RiskAssesment extends React.PureComponent {
  constructor(props) {
    super(props);
    autoBind(this);
  }

  render() {
    return (
      <div>
        <div className="row">
          <div className="col-md-12">
            <div className="form-group">
              <label>Guidance:</label>
              <input
              onChange={event => this.props.handleChangeGuidance(event.target.value)}
                type="guidance"
                className="form-control"
                id="guidance"
                placeholder="Enter a description for this RCSA"
              />
            </div>
          </div>
        </div>
        <br/>
        <div className="row">
          <div className="col-md-12">
            <div className="form-group">
              <label>Year:</label>
              <select name="year" id="year" className="form-control dropList" onChange={event => this.props.handleChangeYear(event.target.value)}>
              <option value="">Please Select</option>
              <option value="2018">2018</option>
              <option value="2019">2019</option>
              <option value="2020">2020</option>
              </select>
            </div>
          </div>
        </div>
        <br/>
        <div className="row">
          <div className="col-md-12">
            <div className="form-group">
              <label>Quarter:</label>
              <select name="quater" id="quater" className="form-control dropList" onChange={event => this.props.handleChangeQuarter(event.target.value)}>
              <option value="">Please Select</option>
              <option value="first">First</option>
              <option value="second">Second</option>
              <option value="third">Third</option>
              <option value="forth">Forth</option>
              </select>
            </div>
          </div>
        </div>
        <br />
        <div className="row">
          <div className="col-md-2">
            <div className="form-group">
              <label>Start Date: </label>
              {' '}{this.props.parentState.startDate
                    ? moment(this.props.parentState.startDate).format('ll')
                    : null}

              <br />
              <button
                type="button"
                className="btn btn-default "
                data-toggle="modal"
                data-target="#myModalDateStart"
              >
                <span
                  className="glyphicon glyphicon-calendar"
                  aria-hidden="true"
                />
              </button>
            </div>
          </div>
          <div className="col-md-2">
            <div className="form-group">
              <label>End Date: </label>
              {' '}{this.props.parentState.endDate
                    ? moment(this.props.parentState.endDate).format('ll')
                    : null}
              <br />
              <button
                type="button"
                className="btn btn-default"
                data-toggle="modal"
                data-target="#myModalDateEnd"
              >
                <span
                  className="glyphicon glyphicon-calendar"
                  aria-hidden="true"
                />
              </button>
            </div>
          </div>
        </div>
        <br />
        <br />
        <hr />
        <p className="lead">Ready to Submit?</p>
        <a onClick={this.props.handleSubmit} className="btn btn-success">
          <span className="glyphicon glyphicon-ok" aria-hidden="true" />
        </a>{" "}
        <a href="" className="btn btn-danger">
          <span className="glyphicon glyphicon-remove" aria-hidden="true" />
        </a>
      </div>
    );
  }
}
