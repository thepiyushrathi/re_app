import * as React from "react";
import { Card } from "reactstrap";
import {
  TreeDataState,
  SortingState,
  SelectionState,
  PagingState,
  CustomTreeData,
  IntegratedFiltering,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  Table,
  TableHeaderRow,
  TableTreeColumn,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility,
  ColumnChooser
} from "@devexpress/dx-react-grid-bootstrap4";

import { Loading } from "./loading";

const ROOT_ID = 0;

const getRowId = row => row.ID;
const getChildRows = (row, rootRows) => {
  const childRows = rootRows.filter(
    r => r.Parent_ID === (row ? row.ID : ROOT_ID)
  );
  if (childRows.length) {
    return childRows;
  }
  return row && row.hasItems ? [] : null;
};

export default class BusinessGrid extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = this.props.currentState;
  }

  // componentDidMount() {
  //   this.loadData();
  // }

  // componentDidUpdate() {
  //   this.loadData();
  // }

  render() {
    const {
      data,
      columns,
      pageSizes,
      defaultColumnWidths,
      expandedRowIds,
      loading,
      defaultHiddenColumnNames
    } = this.props.currentState;

    // function getRowsFromIDs(selectedIDs, dataArray) {
    //   let rowIds = [];
    //   dataArray.forEach((element, index) => {
    //     selectedIDs.forEach(element2 => {
    //       if (element.ID === element2) {
    //         rowIds.push(index+1);
    //       }
    //     });
    //   });
    //   return rowIds;
    // }

    function getSelectedEntityRows(classObj) {
      // let selectedEntityRows = [];
      // console.log('classObj.props.businessEntity.selectedEntityRows[0]', classObj.props.businessEntity.selectedEntityRows[0]);
      // console.log('classObj.props.businessEntity.businessEntity', classObj.props.businessEntity.businessEntity);
      // if (classObj.props.businessEntity.selectedEntityRows[0] !== undefined) {
      //   selectedEntityRows = getRowsFromIDs(
      //     classObj.props.businessEntity.selectedEntityRows[0],
      //     classObj.props.businessEntity.businessEntity
      //   );
      // }
      return classObj.props.businessEntity.selectedEntityRows[0];
    }

    return (
      <Card>
        <Grid
          rows={data}
          columns={columns}
          getRowId={getRowId}
        >
          <TreeDataState
            expandedRowIds={expandedRowIds}
            onExpandedRowIdsChange={this.props.onChangeExpandedRowIds}
          />

          <SortingState />
          <SelectionState selection={getSelectedEntityRows(this)} onSelectionChange={this.props.onEntitySelection}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <CustomTreeData getChildRows={getChildRows} />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table />
          <TableColumnVisibility
            defaultHiddenColumnNames={defaultHiddenColumnNames}
          />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableTreeColumn for="Subject" showSelectionControls showSelectAll />

          <Toolbar />
          <ColumnChooser />

          <PagingPanel pageSizes={pageSizes} />
        </Grid>
        {loading && <Loading />}
      </Card>
    );
  }
}
