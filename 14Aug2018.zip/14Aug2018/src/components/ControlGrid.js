import * as React from "react";
import { Card, UncontrolledTooltip } from "reactstrap";
import {
  DataTypeProvider,
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";

export default class ControlGrid extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      columns: [
        { name: "Resource_ID", title: "Resource ID" },
        { name: "Title", title: "Title" },
        {
          name: "Control_Group",
          title: "Control Group",
          getCellValue: row => row.Control_Group.split("T")[0]
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Control_Owner",
          title: "Control Owner"
        }
      ],
      rows: this.props.controlData.controlFetched[0],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
      ],
      resourceHoverColumns:['Resource_ID']
    };
  }

  componentDidUpdate() {
    this.setState({
      rows: this.props.controlData.controlFetched[0]
    });
  }

  render() {
    const { rows, columns, pageSizes, defaultColumnWidths, resourceHoverColumns } = this.state;

    function getRowsFromIDs(selectedIDs, dataArray){
      let rowIds = [];
      dataArray.forEach((element,index) => {
        selectedIDs.forEach(element2 => {
          if(element.ID === element2){
            rowIds.push(index);
          }
        });
      });
      return rowIds;
    }

    function getSelectedControlRows(classObj) {
      // let selectedControlRows = [];
      // let selectControlRowIDs = [];
      // if(classObj.props.controlData.controlFetched[0].length > 0){
      //   classObj.props.controlData.controlFetched[0].forEach(element => {
      //     selectedControlRows.push(element.ID);
      //   });

      //   selectControlRowIDs = getRowsFromIDs(selectedControlRows, classObj.props.controlData.controlFetched[0]);
      // }
      // return selectControlRowIDs;

      let selectedControlRows =[];
      if(classObj.props.controlData.selectedControlRows[0] !== undefined){
        selectedControlRows = classObj.props.controlData.selectedControlRows[0];
        return selectedControlRows;
      }
    }

    const HoverFormatter = ({ row }) => (
      <div
      style={{
        display: 'flex',
      }}
      >
      <div>
      <a className="anchorDecoration" id={'control'+this.props.controlData.controlFetched[0].find(e => e.ID === row.ID).ID}>
        {row.Resource_ID}
      </a>
      <UncontrolledTooltip placement="right" target={'control'+row.ID}>
        <div className="tooltipDecor">
        <table className="childList">
        <tbody>
          <tr><td><span className="tooltipLabel">Resource ID </span></td><td>{row.Resource_ID}</td></tr>
          <tr><td><span className="tooltipLabel">Title </span></td><td>{row.Title}</td></tr>
          <tr><td><span className="tooltipLabel">Control Group </span></td><td>{row.Control_Group}</td></tr>
          <tr><td><span className="tooltipLabel">Scope </span></td><td>{row.Scope}</td></tr>
          <tr><td><span className="tooltipLabel">Control Owner </span></td><td>{row.Control_Owner}</td></tr>
          </tbody>
          </table>
        </div>
      </UncontrolledTooltip>
      </div>

      </div>
    );

    return (
      <Card>
        <Grid rows={rows} columns={columns}>
        <DataTypeProvider
            for={resourceHoverColumns}
            formatterComponent={HoverFormatter}
          />
          <FilteringState />
          <SortingState />
          <SelectionState selection={getSelectedControlRows(this)} />
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table />
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection
            for="Resource_ID"
            showSelectionControls
            showSelectAll
          />

          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
        </Grid>
      </Card>
    );
  }
}
