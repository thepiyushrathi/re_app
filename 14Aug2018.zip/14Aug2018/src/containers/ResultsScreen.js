import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from "react-redux";
import * as raReducer from "../store/riskAssesment/reducer";
// import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Alert } from 'reactstrap';

import { Link } from "react-router-dom";

class ResultsScreen extends Component {
  constructor(props) {
    super(props);
    autoBind(this);
  }

  render() {
    if (!this.props.raData[0]) return this.renderLoading();
    return (
      <div>
        <div className="container BusinessScreen">
          <div className="row firstRow">
            <div className="col-md-6">
              <h1>
            <Link to="/">
              <img src={"./imgs/MetLife.png"} alt="logo" className="mllogo" />
            </Link>{" "}
            RCSA Assistant
          </h1>
            </div>
            <div className="col-md-6" />
          </div>

                          <div className="row">
                <hr/><br/>
            <div className="col-md-6">
                <h2>RCSA submitted:</h2>
                <p>
                    Name: <strong><a href="">{this.props.raData[0].name}</a></strong><br/>
                Date: {this.props.raData[0].date}<br/>
                Time: {this.props.raData[0].time}<br/>
                Created by: {this.props.raData[0].createdBy}<br/>
                </p>
            </div> 
        </div>
                             <Link to="/" className="btn btn-default">Done</Link> 
        </div>


      </div>
    );
  }

  renderLoading() {
    return <p>Loading...</p>;
  }
}

function mapStateToProps(state) {
  return {
    raData : raReducer.getRaData(state)
  };
}

export default connect(mapStateToProps)(ResultsScreen);
