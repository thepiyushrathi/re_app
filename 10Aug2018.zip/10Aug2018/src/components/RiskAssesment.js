import * as React from "react";
import autoBind from "react-autobind";
import { Link } from "react-router-dom";
import moment from "moment";

export default class RiskAssesment extends React.PureComponent {
  constructor(props) {
    super(props);
    autoBind(this);
  }

  render() {
      console.log('asdbhgsdgasdsk',this.props);
    return (
      <div>
        <div className="row">
          <div className="col-md-12">
            <div className="form-group">
              <label>Guidance:</label>
              <input
              onChange={event => this.props.handleChangeGuidance(event.target.value)}
                type="guidance"
                className="form-control"
                id="guidance"
                placeholder="Enter a description for this RCSA"
              />
            </div>
          </div>
        </div>
        <br />
        <div className="row">
          <div className="col-md-2">
            <div className="form-group">
              <label>Start Date: </label>
              {' '}{this.props.parentState.startDate
                    ? moment(this.props.parentState.startDate).format('ll')
                    : null}

              <br />
              <button
                type="button"
                className="btn btn-default "
                data-toggle="modal"
                data-target="#myModalDateStart"
              >
                <span
                  className="glyphicon glyphicon-calendar"
                  aria-hidden="true"
                />
              </button>
            </div>
          </div>
          <div className="col-md-2">
            <div className="form-group">
              <label>End Date: </label>
              {' '}{this.props.parentState.endDate
                    ? moment(this.props.parentState.endDate).format('ll')
                    : null}
              <br />
              <button
                type="button"
                className="btn btn-default"
                data-toggle="modal"
                data-target="#myModalDateEnd"
              >
                <span
                  className="glyphicon glyphicon-calendar"
                  aria-hidden="true"
                />
              </button>
            </div>
          </div>
        </div>
        <br />
        <br />
        <hr />
        <p className="lead">Ready to Submit?</p>
        <a onClick={this.props.handleSubmit} className="btn btn-success">
          <span className="glyphicon glyphicon-ok" aria-hidden="true" />
        </a>{" "}
        <a href="" className="btn btn-danger">
          <span className="glyphicon glyphicon-remove" aria-hidden="true" />
        </a>
      </div>
    );
  }
}
