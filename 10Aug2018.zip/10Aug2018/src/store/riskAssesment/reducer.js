import _ from 'lodash';
import * as types from './actionTypes';
import Immutable from 'seamless-immutable';

const initialState = Immutable({
  guidanceData: undefined,
  raData : undefined
});

export default function reduce(state = initialState, action = {}) {
  switch (action.type) {
    case types.PRC_SUBMIT:
      return Object.assign({}, state,{
        guidanceData: action.guidanceData
      });
    case types.RA_FETCHED:
      return Object.assign({}, state,{
        raData: action.raData
      });
    default:
      return state;
  }
}

export function getGuidanceData(state) {
  const guidanceData = state.riskAssesment.guidanceData;
  console.log('Heyyyyyyy', guidanceData);
  return [guidanceData];
}

export function getRaData(state) {
  const raData = state.riskAssesment.raData;
  return [raData];
}


