export const ENTITY_FETCHED = 'business.ENTITY_FETCHED';
export const ENTITY_SELECTED = 'business.ENTITY_SELECTED';
