import * as React from "react";
import { Card } from "reactstrap";
import {
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";

export default class ControlGrid extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      columns: [
        { name: "Resource_ID", title: "Resource ID" },
        { name: "Title", title: "Title" },
        {
          name: "Control_Group",
          title: "Control Group",
          getCellValue: row => row.Control_Group.split("T")[0]
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Control_Owner",
          title: "Control Owner",
          getCellValue: row => row.Control_Owner.split("T")[0]
        }
      ],
      rows: this.props.controlData.controlFetched[0],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
        { columnName: "Resource_ID", width: 100 },
        { columnName: "Title", width: 80 },
        { columnName: "Control_Group", width: 120 },
        { columnName: "Scope", width: 80 },
        { columnName: "Control_Owner", width: 120 }
      ]
    };
  }

  render() {
    const {
      rows,
      columns,
      pageSizes,
      defaultColumnWidths
    } = this.state;

    let selectedControlRows =[];
    if(this.props.controlData.selectedControlRows[0] != undefined){
      selectedControlRows = this.props.controlData.selectedControlRows[0];
    }

    return (
      <Card>
        <Grid rows={rows} columns={columns}>

          <FilteringState />
          <SortingState />
          <SelectionState selection={selectedControlRows}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table/>
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection  for="Resource_ID" showSelectionControls showSelectAll />

          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
          
        </Grid>
      </Card>
    );
  }
}
