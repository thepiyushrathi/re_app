import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from "react-redux";
import * as topicsActions from "../store/business/actions";
import * as topicsSelectors from "../store/business/reducer";

import BusinessGrid from "../components/BusinessGrid";
import { Link } from "react-router-dom";

class BusinessScreen extends Component {
  constructor(props) {
    super(props);
    autoBind(this);
  }

  componentDidMount() {
    this.props.dispatch(topicsActions.fetchTopics());
  }
  componentDidUpdate() {
    var eyeIcon = document.getElementsByClassName("oi-eye");
    if (eyeIcon != undefined) {
      eyeIcon[0].classList.add("glyphicon");
      eyeIcon[0].classList.add("glyphicon-eye-open");
    }
  }

  render() {
    console.log('gggggggggggggg',this.props);
    if (!this.props.businessEntity) return this.renderLoading();
    return (
      <div className="container BusinessScreen">
      <div className="row firstRow">
        <div className="col-md-6">
          <h1>
            <a href="index.html">
              <img src={"./imgs/MetLife.png"} alt="logo" className="mllogo" />
            </a>{" "}
            RCSA Assistant
          </h1>
        </div>
        <div className="col-md-6" />
      </div>
        <div className="row">
          <hr />
          <br />
          <div className="col-md-12">
            <BusinessGrid businessEntity={this.props.businessEntity}/>
            <div className="row lastRow">
            <br />
              <hr />
                <Link to="/process" className="btn btn-success">
                <span className="glyphicon glyphicon-ok" aria-hidden="true" />
                </Link>
              <a href="index.html" className="btn btn-danger">
                <span
                  className="glyphicon glyphicon-remove"
                  aria-hidden="true"
                />
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  renderLoading() {
    return <p>Loading...</p>;
  }

}

function mapStateToProps(state) {
  const [businessEntity] = topicsSelectors.getTopics(state);
  return {
    businessEntity,
    selectedBusinessEntity: topicsSelectors.getSelectedBusinessEntity(state),
    canFinalizeSelection: topicsSelectors.isTopicSelectionValid(state)
  };
}

export default connect(mapStateToProps)(BusinessScreen);
