// strings should be unique across reducers so namespace them with the reducer name

export const PROCESS_FETCHED = 'process.PROCESS_FETCHED';
export const FILTER_CHANGED = 'process.FILTER_CHANGED';
export const PROCESS_SELECTED = 'process.PROCESS_SELECTED';
export const RISK_SELECTED = 'process.RISK_SELECTED';
export const CONTROL_SELECTED = 'process.CONTROL_SELECTED';
