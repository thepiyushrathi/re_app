import _ from 'lodash';
import * as types from './actionTypes';
import dataService from '../../services/metlife';

export function fetchProcess(selectedEntities) {
  return async(dispatch, getState) => {
    try {
      const processArray = await dataService.getProcessData(selectedEntities);
      dispatch({ type: types.PROCESS_FETCHED, processArray });
    } catch (error) {
      console.error(error);
    }
  };
}

export function fetchRisk(processID) {
  return async(dispatch, getState) => {
    try {
      const riskArray = await dataService.getRiskDataService(processID);
      console.log('riskArray', riskArray);
      dispatch({ type: types.RISK_FETCHED, riskArray });
    } catch (error) {
      console.error(error);
    }
  };
}

export function fetchControl(riskID) {
  return async(dispatch, getState) => {
    try {
      const controlArray = await dataService.getControlDataService(riskID);
      console.log('controlArray', controlArray);
      dispatch({ type: types.CONTROL_FETCHED, controlArray });
    } catch (error) {
      console.error(error);
    }
  };
}

export function setSelectedProcessRows(selectedProcessRows){
  return({ type: types.PROCESS_SELECTED, selectedProcessRows });
}

export function setSelectedRiskRows(selectedRiskRows){
  return({ type: types.RISK_SELECTED, selectedRiskRows });
}

export function setSelectedControlRows(selectedControlRows){
  return({ type: types.CONTROL_SELECTED, selectedControlRows });
}