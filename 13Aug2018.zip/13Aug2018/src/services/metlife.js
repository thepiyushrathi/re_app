//service to get data for business entity page.
import _ from 'lodash';

const SERVER_ENDPOINT = 'http://localhost:3000/';
const URL = 'http://demo0603099.mockable.io/treeListData';

class DataService {

  async getDefaultSubmetlifes() {
    const url = `${SERVER_ENDPOINT}/data.json`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Accept: 'application/json'
      }
    });
    if (!response.ok) {
      throw new Error(`getDefaultSubmetlifes failed, HTTP status ${response.status}`);
    }
    const data = await response.json();
    return data;
  }

  async getLazyData(rowId){
    console.log("getLazyData(rowId)");
    const url = `${URL}/parentIds/${rowId}`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Accept: 'application/json'
      }
    });
    if (!response.ok) {
      throw new Error(`getLazyData failed, HTTP status ${response.status}`);
    }
    const data = await response.json();
    return data;

  }

  async getProcessData(selectedEntities) {
    const url = `http://demo4140263.mockable.io/getprocessdata`;
    const response = await fetch(url, {
      method: 'POST',
      body: JSON.stringify(selectedEntities),
      headers: {
        Accept: 'application/json'
      }
    });
    if (!response.ok) {
      throw new Error(`getProcessData failed, HTTP status ${response.status}`);
    }
    const data = await response.json();
    return data;
  }

  async getRiskDataService(processID) {
    const url = `http://demo4140263.mockable.io/getriskdata`;
    const response = await fetch(url, {
      method: 'POST',
      body: JSON.stringify(processID),
      headers: {
        Accept: 'application/json'
      }
    });
    if (!response.ok) {
      throw new Error(`getRiskDataService failed, HTTP status ${response.status}`);
    }
    const data = await response.json();
    return data;
  }

  async getControlDataService(riskID){
    const url = `http://demo4140263.mockable.io/getcontroldata`;
    const response = await fetch(url, {
      method: 'POST',
      body: JSON.stringify(riskID),
      headers: {
        Accept: 'application/json'
      }
    });
    if (!response.ok) {
      throw new Error(`getControlDataService failed, HTTP status ${response.status}`);
    }
    const data = await response.json();
    return data;
  }

  async getRaData(sendData){
    const url = `http://demo4140263.mockable.io/getradata`;
    const response = await fetch(url, {
      method: 'POST',
      body: JSON.stringify(sendData),
      headers: {
        Accept: 'application/json'
      }
    });
    if (!response.ok) {
      throw new Error(`getRaData failed, HTTP status ${response.status}`);
    }
    const data = await response.json();
    return data;
  }

  _validateUrl(url = '') {
    return url.startsWith('http') ? url : undefined;
  }

}

export default new DataService();
