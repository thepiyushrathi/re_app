import * as React from "react";
import { Card, UncontrolledTooltip } from "reactstrap";
import {
  DataTypeProvider,
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";


export default class RiskGrid extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      columns: [
        { name: "Resource_ID", title: "Resource ID" },
        { name: "Title", title: "Title" },
        {
          name: "Risk_Group",
          title: "Risk Group",
          getCellValue: row => row.Risk_Group.split("T")[0]
        },
        {
          name: "Risk_Category",
          title: "Risk Category",
          getCellValue: row => row.Risk_Category.split("T")[0]
        },
        {
          name: "Risk",
          title: "Risk"
        },
        {
          name: "Risk_Rating_Quarter",
          title: "Risk Rating Quarter",
          getCellValue: row => row.Risk_Rating_Quarter.split("T")[0]
        },
        {
          name: "Risk_Rating_Year",
          title: "Risk Rating Year",
          getCellValue: row => row.Risk_Rating_Year.split("T")[0]
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Owner",
          title: "Owner"
        }
      ],
      rows: this.props.riskData.riskFetched[0],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
      ],
      resourceHoverColumns:['Resource_ID']
    };
  }

  componentDidUpdate() {
    this.setState({
      rows: this.props.riskData.riskFetched[0]
    });
  }

  render() {
    console.log('this.props', this.props);
    const {
      rows,
      columns,
      pageSizes,
      defaultColumnWidths,
      resourceHoverColumns
    } = this.state;

    const HoverFormatter = ({ row }) => (
      <div
      style={{
        display: 'flex',
      }}
      >
      <div>
      <a onClick={()=>this.props.getControlsData(row.ID)} className="anchorDecoration" id={'risk'+this.props.riskData.riskFetched[0].find(e => e.ID === row.ID).ID}>
        {row.Resource_ID}
      </a>
      <UncontrolledTooltip placement="right" target={'risk'+row.ID}>
        <div className="tooltipDecor">
        <table className="childList">
        <tbody>
          <tr><td><span className="tooltipLabel">Resource ID :</span></td><td>{row.Resource_ID}</td></tr>
          <tr><td><span className="tooltipLabel">Title :</span></td><td>{row.Title}</td></tr>
          <tr><td><span className="tooltipLabel">Risk Group :</span></td><td>{row.Risk_Group}</td></tr>
          <tr><td><span className="tooltipLabel">Risk Category :</span></td><td>{row.Risk_Category}</td></tr>
          <tr><td><span className="tooltipLabel">Risk :</span></td><td>{row.Risk}</td></tr>
          <tr><td><span className="tooltipLabel">Risk Rating Quarter :</span></td><td>{row.Risk_Rating_Quarter}</td></tr>
          <tr><td><span className="tooltipLabel">Risk Rating Year :</span></td><td>{row.Risk_Rating_Year}</td></tr>
          <tr><td><span className="tooltipLabel">Scope :</span></td><td>{row.Scope}</td></tr>
          <tr><td><span className="tooltipLabel">Owner :</span></td><td>{row.Owner}</td></tr>
          </tbody>
          </table>
        </div>
      </UncontrolledTooltip>
      </div>

      </div>
    );

    function findChilds(ID, dataArray){
      let selectChilds = [];
      dataArray.forEach(element => {
        if(element.Risk_ID === ID){
          selectChilds.push(element);
        }
      });
      return selectChilds;
    }

    function getRowsFromIDs(selectedIDs, dataArray){
      let rowIds = [];
      dataArray.forEach((element,index) => {
        selectedIDs.forEach(element2 => {
          if(element.ID === element2){
            rowIds.push(index);
          }
        });
      });
      return rowIds;
    }

    function getSelectedRiskRows(classObj) {
      let selectedRiskRows =[];
      let selectRiskRowIDs = [];
      if(classObj.props.riskData.riskFetched[0].length > 0){
        classObj.props.riskData.riskFetched[0].forEach(element => {
          selectedRiskRows.push(element.ID);
        });
        selectRiskRowIDs = getRowsFromIDs(selectedRiskRows, classObj.props.riskData.riskFetched[0]);
      }
        return selectRiskRowIDs;
      }
    return (
      <Card>
        <Grid rows={rows} columns={columns}>
        <DataTypeProvider
            for={resourceHoverColumns}
            formatterComponent={HoverFormatter}
          />
          <FilteringState />
          <SortingState />
          <SelectionState selection={getSelectedRiskRows(this)} onSelectionChange={this.props.onRiskSelectionChange}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table/>
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection  for="Resource_ID" showSelectionControls showSelectAll />
          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
          
        </Grid>
      </Card>
    );
  }
}
