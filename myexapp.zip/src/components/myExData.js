import React, { Component } from "react";
import { ExcelRenderer } from "react-excel-renderer";
import { ManagedataFormRow, ManagedataCell } from "./managedata";
import { Table, Button, Popconfirm, Row, Col, Icon, Upload } from "antd";

export default class MyExData extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cols: [],
      rows: [],
      errorMessage: null,
      columns: [
        {
          title: "Name",
          dataIndex: "name",
          editable: true
        },
        {
          title: "Department",
          dataIndex: "department",
          editable: true
        },
		{
          title: "Organisation",
          dataIndex: "organisation",
          editable: true
        },
		{
          title: "Address",
          dataIndex: "address",
          editable: true
        },
        {
          title: "Delete Row",
          dataIndex: "action",
          render: (text, record) =>
            this.state.rows.length >= 1 ? (
              <Popconfirm
                title="confirm delete?"
                onConfirm={() => this.handleDelete(record.key)}
              >
			  <Icon type="close" />
              </Popconfirm>
            ) : null
        }
      ]
    };
  }
  

  fileHandler = fileList => {
    let fileObj = fileList;
	console.log(fileObj);
    if (!fileObj) {
      this.setState({
        errorMessage: "No file uploaded!"
      });
      return false;
    }
    console.log("fileObj.type:", fileObj.type);
    if (
      !(
        fileObj.type === "application/vnd.ms-excel" ||
        fileObj.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      )
    ) {
      this.setState({
        errorMessage: "Only Excel acceptable!!!"
      }, alert("Only Excel acceptable!!!"));
      return false;
    }
    else {
    ExcelRenderer(fileObj, (err, resp) => {
      if (err) {
        console.log(err);
      } else {
		  console.log(resp.rows[0]);
        let newRows = [];
        resp.rows.slice(1).map((row, index) => {
          if (row && row !== "undefined") {
            newRows.push({
              key: index,
              name: row[0],
              department: row[1],
              organisation: row[2],
			  address: row[3]
            });
          }
        });
        if (newRows.length === 0) {
          this.setState({
            errorMessage: "No data found in file!"
          });
          return false;
        } else {
          this.setState({
            cols: resp.cols,
            rows: newRows,
            errorMessage: null
          });
        }
      }
    });
	}
    return false;
  };

  handleDelete = key => {
    const rows = [...this.state.rows];
    this.setState({ rows: rows.filter(item => item.key !== key) });
  };
  handleSave = row => {
    const newData = [...this.state.rows];
    const index = newData.findIndex(item => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, {
      ...item,
      ...row
    });
    this.setState({ rows: newData });
  };

  render() {
    const components = {
      body: {
        row: ManagedataFormRow,
        cell: ManagedataCell
      }
    };
    const columns = this.state.columns.map(col => {
      if (!col.editable) {
        return col;
      }
      return {
        ...col,
        onCell: record => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
		  handleSave: this.handleSave
        })
      };
    });
    return (
      <>
	  <div style={{ display: 'block',textAlign:'center', paddingBottom: 20, backgroundColor: '#71de71'}}>
        <h1>My Excel Data</h1>
          <Upload
			multiple={false}
            name="file"
            beforeUpload={this.fileHandler}
            onRemove={() => this.setState({ rows: [] })}
          >
            <Button type="primary">
              <Icon type="upload" /> Upload Excel File
            </Button>
          </Upload>
        </div>
        <div style={{ marginTop: 20 }}>
          <Table
            components={components}
            rowClassName={() => "editable-row"}
            dataSource={this.state.rows}
            columns={columns}
          />
        </div>
      </>
    );
  }
}
