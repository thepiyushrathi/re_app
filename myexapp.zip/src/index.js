import React from "react";
import ReactDOM from "react-dom";
import "antd/dist/antd.css";
import MyExData from "./components/myExData";

function App() {
  return (
    <>
      <MyExData />
    </>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
