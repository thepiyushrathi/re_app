import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from "react-redux";
import * as postsActions from "../store/process/actions";
import * as postsSelectors from "../store/process/reducer";
import * as topicsSelectors from "../store/business/reducer";

import { Link } from "react-router-dom";
import ProcessGrid from '../components/ProcessGrid';
import RiskGrid from '../components/RiskGrid';
import ControlGrid from '../components/ControlGrid';

class ProcessScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      entityFetched: false
    };
    autoBind(this);
  }
  componentDidMount() {
    this.props.dispatch(postsActions.fetchProcess(this.props.selectedEntityRows[0]));
  }
  componentDidUpdate() {
    if (this.props.processFetched[0] !== undefined && !this.state.entityFetched){
      this.getChildProcessFromEntity();
    }
  }

  render() {
    if (!this.props.processFetched[0]) return this.renderLoading();
    return (
      <div className="container BusinessScreen fullWidth">
      <div className="row firstRow">
        <div className="col-md-6">
          <h1>
          <Link to="/">
              <img src={"./imgs/MetLife.png"} alt="logo" className="mllogo" />
            </Link>{" "}
            RCSA Assistant
          </h1>
        </div>
        <div className="col-md-6" />
      </div>
      <div className="ProcessScreen">
        <div className="row">
          <hr />
          <br />
          <div className="col-md-4">
            <h2>
              Process Selection
              <button
                type="button"
                className="btn btn-default btn-sm"
                data-toggle="modal"
                data-target="#myModalPrAdd"
              >
                <span className="glyphicon glyphicon-plus" aria-hidden="true" />
              </button>
            </h2>
            <ProcessGrid getRisksData={this.getRisksData} processData={this.props} onSelectionChange={this.onSelectionChange}/>
          </div>
          <div className="col-md-4">
            <h2>
              Risk Selection
              <button
                type="button"
                className="btn btn-default btn-sm"
                data-toggle="modal"
                data-target="#myModalRskAdd"
              >
                <span className="glyphicon glyphicon-plus" aria-hidden="true" />
              </button>
            </h2>
            <RiskGrid getControlsData={this.getControlsData} riskData={this.props} onRiskSelectionChange={this.onRiskSelectionChange}/>
          </div>
          <div className="col-md-4">
            <h2>
              Control Selection
              <button
                type="button"
                className="btn btn-default btn-sm"
                data-toggle="modal"
                data-target="#myModalCtlAdd"
              >
                <span className="glyphicon glyphicon-plus" aria-hidden="true" />
              </button>
            </h2>
            <ControlGrid controlData={this.props}/>
            </div>
          </div>

              
          <div
            className="modal fade"
            id="myModalPrAdd"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="myModalLabel"
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <h4 className="modal-title" id="myModalLabel">
                    + Processes
                  </h4>
                </div>
                <div className="modal-body">
                  <form>
                    <div className="form-group">
                      <label htmlFor="exampleInputEmail1">
                        Enter the name of the Process:
                      </label>
                      <input
                        type="text"
                        className="form-control col-md-6"
                        id="exampleInputEmail1"
                        placeholder="P-00000"
                      />
                    </div>
                  </form>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-default"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div
            className="modal fade"
            id="myModalRskAdd"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="myModalLabel"
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <h4 className="modal-title" id="myModalLabel">
                    + Risks
                  </h4>
                </div>
                <div className="modal-body">
                  <form>
                    <div className="form-group">
                      <label htmlFor="exampleInputEmail1">
                        Enter the name of the Risk:
                      </label>
                      <input
                        type="text"
                        className="form-control col-md-6"
                        id="exampleInputEmail1"
                        placeholder="R-00000"
                      />
                    </div>
                  </form>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-default"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div
            className="modal fade"
            id="myModalCtlAdd"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="myModalLabel"
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                  <h4 className="modal-title" id="myModalLabel">
                    + Controls
                  </h4>
                </div>
                <div className="modal-body">
                  <form>
                    <div className="form-group">
                      <label htmlFor="exampleInputEmail1">
                        Enter the name of the Control:
                      </label>
                      <input
                        type="text"
                        className="form-control col-md-6"
                        id="exampleInputEmail1"
                        placeholder="C-00000"
                      />
                    </div>
                </form>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row lastRow">
          <br />
          <hr />
          <div className="marLeft5">
          <Link to="/riskassesment" className="btn btn-success">
                <span className="glyphicon glyphicon-ok" aria-hidden="true" />
                </Link>
                <Link to="/" className="btn btn-danger">
                <span
                  className="glyphicon glyphicon-remove"
                  aria-hidden="true"
                />
                </Link>
                </div>
                </div>
      </div>
      </div>
    );
  }

  renderLoading() {
    return <p>Loading...</p>;
  }

  getRisksData(processID){
    // this.onSelectionChange([processID]);
    this.props.dispatch(postsActions.fetchRisk(processID));
  }
  getControlsData(riskID){
    this.props.dispatch(postsActions.fetchControl(riskID));
  }

  onRowClick(postId) {
    this.props.dispatch(postsActions.selectPost(postId));
  }

  getIDfromRows(selectedRowIds, dataArray){
    let realIDs = [];
    selectedRowIds.forEach(element => {
      realIDs.push(dataArray[element].ID);
    });
    return realIDs;
  }

  getRowsFromIDs(selectedIDs, dataArray){
    let rowIds = [];
    dataArray.forEach((element,index) => {
      selectedIDs.forEach(element2 => {
        if(element.ID === element2){
          rowIds.push(index);
        }
      });
    });
    return rowIds;
  }

  getChildProcessFromEntity(){
    this.setState({
      entityFetched: !this.state.entityFetched
    });
    let entityIds = this.props.selectedEntityRows[0];
    let selectProcessIds = [];
    let selectedProcessRowIDs = [];
    if(entityIds !== undefined && entityIds.length > 0){
      entityIds.forEach(element => {
        if(this.props.processFetched[0] !== undefined && this.props.processFetched[0].length > 0){
          this.props.processFetched[0].forEach(element2 => {
            if(element2.Parent_ID === element){
              selectProcessIds.push(element2.ID);
            }
          });
        }
      });
    }
    selectedProcessRowIDs = this.getRowsFromIDs(selectProcessIds, this.props.processFetched[0]);
    this.props.dispatch(postsActions.setSelectedProcessRows(selectedProcessRowIDs));
    this.onSelectionChange(selectedProcessRowIDs);
  }

  getChildRisk(selectedRows){
    let processIds = this.getIDfromRows(selectedRows, this.props.processFetched[0]);
    let selectRiskIds = [];
    let selectRiskRowIDs = [];
    processIds.forEach(element => {
      this.props.riskFetched[0].forEach(element2 => {
        if(element2.Process_ID === element){
          selectRiskIds.push(element2.ID);
        }
      });
    });
    selectRiskRowIDs = this.getRowsFromIDs(selectRiskIds, this.props.riskFetched[0]);
    return selectRiskRowIDs;

  }

  getChildControls(selectedRows){
    let riskIds = this.getIDfromRows(selectedRows, this.props.riskFetched[0]);
    let selectControlIds = [];
    let selectControlRowIDs = [];
    riskIds.forEach(element => {
      this.props.controlFetched[0].forEach(element2 => {
        if(element2.Risk_ID === element){
          selectControlIds.push(element2.ID);
        }
      });
    });
    selectControlRowIDs = this.getRowsFromIDs(selectControlIds, this.props.controlFetched[0]);
    return selectControlRowIDs;

  }

  onSelectionChange(eve){
    // let selectRiskIds = [];
    // let selectControlIds = [];
    //dispatch an action here to update value of selected process rows
    this.props.dispatch(postsActions.setSelectedProcessRows(eve));
    
    ////update child rows selectionArray here.
    // selectRiskIds = this.getChildRisk(eve);
    // selectControlIds = this.getChildControls(selectRiskIds);

    // this.props.dispatch(postsActions.setSelectedRiskRows(selectRiskIds));
    // this.props.dispatch(postsActions.setSelectedControlRows(selectControlIds));
    
    // if(this.props.selectedProcessRows[0] !== undefined){
    //   // console.log('PROPS in RISK', this.props);
    // }
    
    ///add selected row id(array indexNo.) in store/state
    ///pass to the 'risk page' & make child rows selected
  }

  onRiskSelectionChange(eve){
    let selectRiskIds = [];
    // let selectControlIds = [];
    
    ////update child rows selectionArray here.
    selectRiskIds = eve;
    // selectControlIds = this.getChildControls(selectRiskIds);

    this.props.dispatch(postsActions.setSelectedRiskRows(selectRiskIds));
    // this.props.dispatch(postsActions.setSelectedControlRows(selectControlIds));

  }

}

function mapStateToProps(state) {
  return {
    processFetched: postsSelectors.getProcessFetched(state),
    riskFetched: postsSelectors.getRiskFetched(state),
    controlFetched: postsSelectors.getControlFetched(state),
    selectedEntityRows: topicsSelectors.getSelectedEntityRows(state),
    selectedProcessRows: postsSelectors.getSelectedProcessRows(state),
    selectedRiskRows: postsSelectors.getSelectedRiskRows(state),
    selectedControlRows: postsSelectors.getSelectedControlRows(state)
  };
}

export default connect(mapStateToProps)(ProcessScreen);
