import * as React from "react";
import autoBind from "react-autobind";
import { Card,UncontrolledTooltip } from "reactstrap";
import {
  DataTypeProvider,
  SearchState,
  SortingState,
  SelectionState,
  FilteringState,
  PagingState,
  IntegratedPaging,
  IntegratedSorting,
  IntegratedFiltering,
  IntegratedSelection
} from "@devexpress/dx-react-grid";
import {
  Grid,
  SearchPanel,
  Table,
  TableHeaderRow,
  TableSelection,
  PagingPanel,
  TableColumnResizing,
  Toolbar,
  TableColumnVisibility
} from "@devexpress/dx-react-grid-bootstrap4";

export default class ProcessGrid extends React.PureComponent {
  constructor(props) {
    super(props);
    autoBind(this);

    this.state = {
      columns: [
        { name: "Resource_ID", 
        title: "Resource ID" ,
        getCellValue: row => row.Resource_ID.split("T")[0] },
        { name: "Title", title: "Title" },
        {
          name: "Process_Category",
          title: "Process Category"
        },
        {
          name: "Process",
          title: "Process"
        },
        {
          name: "Scope",
          title: "Scope"
        },
        {
          name: "Process_Owner",
          title: "Process Owner"
        }
      ],
      rows: this.props.processData.processFetched[0],
      pageSizes: [5, 10, 20],
      defaultColumnWidths: [
      ],
      resourceHoverColumns:['Resource_ID']
    };
  }

  render() {
    const {
      rows,
      columns,
      pageSizes,
      defaultColumnWidths,
      resourceHoverColumns
    } = this.state;

    const HoverFormatter = ({ row }) => (
      <div
        style={{
          display: 'flex',
        }}
      >
      <div>
        <a onClick={()=>this.props.getRisksData(row.ID)} className="anchorDecoration" id={'process'+this.props.processData.processFetched[0].find(e => e.ID === row.ID).ID}>
          {row.Resource_ID}
        </a>
        <UncontrolledTooltip placement="right" target={'process'+row.ID}>
          <div className="tooltipDecor">
          <table className="childList">
          <tbody>
            <tr><td><span className="tooltipLabel">Resource ID </span></td><td>{row.Resource_ID}</td></tr>
            <tr><td><span className="tooltipLabel">Process Category </span></td><td>{row.Process_Category}</td></tr>
            <tr><td><span className="tooltipLabel">Process </span></td><td>{row.Process}</td></tr>
            <tr><td><span className="tooltipLabel">Scope </span></td><td>{row.Scope}</td></tr>
            <tr><td><span className="tooltipLabel">Process Owner </span></td><td>{row.Process_Owner}</td></tr>
            </tbody>
            </table>
          </div>
        </UncontrolledTooltip>
        </div>
        
      </div>
    );

    // function findChilds(ID, dataArray){
    //   let selectChilds = [];
    //   dataArray.forEach(element => {
    //     if(element.Process_ID === ID){
    //       selectChilds.push(element);
    //     }
    //   });
    //   return selectChilds;
    // }

    function getRowsFromIDs(selectedIDs, dataArray){
      let rowIds = [];
      dataArray.forEach((element,index) => {
        selectedIDs.forEach(element2 => {
          if(element.ID === element2){
            rowIds.push(index);
          }
        });
      });
      return rowIds;
    }
    
    function getSelectedProcessRows(classObj) {
      let selectedProcessRows =[];
      if(classObj.props.processData.selectedProcessRows[0] !== undefined && classObj.props.processData.selectedProcessRows[0].length > 0){
        selectedProcessRows = classObj.props.processData.selectedProcessRows[0];
        return selectedProcessRows;
      }else if(classObj.props.processData.selectedProcessRows[0] === undefined){
        let selectProcessRowIDs = [];
        if(classObj.props.processData.processFetched[0].length > 0){
          classObj.props.processData.processFetched[0].forEach(element => {
            selectedProcessRows.push(element.ID);
          });
          selectProcessRowIDs = getRowsFromIDs(selectedProcessRows, classObj.props.processData.processFetched[0]);
        }
          return selectProcessRowIDs;
      }
    }

    return (
      <Card>
        <Grid rows={rows} columns={columns}>
        <DataTypeProvider
            for={resourceHoverColumns}
            formatterComponent={HoverFormatter}
          />
          <FilteringState />
          <SortingState />
          <SelectionState selection={getSelectedProcessRows(this)} onSelectionChange={this.props.onSelectionChange}/>
          <PagingState defaultCurrentPage={0} defaultPageSize={pageSizes[1]} />

          <SearchState defaultValue="" />
          <IntegratedFiltering />
          <IntegratedSelection />
          <IntegratedSorting />
          <IntegratedPaging />

          <Table/>
          <TableColumnVisibility />
          <TableColumnResizing defaultColumnWidths={defaultColumnWidths} />
          <TableHeaderRow showSortingControls />

          <TableSelection for="Resource_ID" showSelectionControls showSelectAll />
          <Toolbar />
          <SearchPanel />
          <PagingPanel pageSizes={pageSizes} />
          
        </Grid>
      </Card>
    );
  }
}
