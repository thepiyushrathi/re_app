import business from './business/reducer';
import process from './process/reducer';
import riskAssesment from './riskAssesment/reducer';

export {
  business,
  process,
  riskAssesment
};
